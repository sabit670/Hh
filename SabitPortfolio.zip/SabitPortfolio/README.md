# SABIT SIDIQUE - Personal Portfolio App (Java)
1. Open this folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. Run on a phone/emulator (Android 7.0+).
3. Edit everything about you in:
   app/src/main/java/com/sabit/portfolio/utils/AppConfig.java
   (name, intro, skills, WhatsApp number, social links, projects)
4. Profile photo: app/src/main/res/drawable-nodpi/profile.jpg
