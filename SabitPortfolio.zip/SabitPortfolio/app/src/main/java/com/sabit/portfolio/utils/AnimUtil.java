package com.sabit.portfolio.utils;

import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** Small reusable animations (fade + slide-up, button press effect). */
public final class AnimUtil {
    private AnimUtil() {}

    public static void fadeSlideUp(View v, long delayMs) {
        v.setAlpha(0f);
        v.setTranslationY(60f);
        v.animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(500)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    /** Shrinks the view slightly while it is pressed. Clicks still work normally. */
    @SuppressWarnings("ClickableViewAccessibility")
    public static void pressEffect(View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(150).start();
            }
            return false;
        });
    }
}
