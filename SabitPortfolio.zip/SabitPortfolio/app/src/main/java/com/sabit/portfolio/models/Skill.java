package com.sabit.portfolio.models;

/** One skill card (level is 0-100). */
public class Skill {
    public final String name, description;
    public final int level;

    public Skill(String name, String description, int level) {
        this.name = name; this.description = description; this.level = level;
    }
}
