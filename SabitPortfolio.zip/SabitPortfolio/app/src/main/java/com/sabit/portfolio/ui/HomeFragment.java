package com.sabit.portfolio.ui;

import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.sabit.portfolio.R;
import com.sabit.portfolio.utils.AnimUtil;
import com.sabit.portfolio.utils.AppConfig;
import com.sabit.portfolio.utils.IntentUtil;

public class HomeFragment extends Fragment {
    private View root;
    private ObjectAnimator glowAnim;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        root = v.findViewById(R.id.homeRoot);
        ((ImageView) v.findViewById(R.id.ivProfile)).setImageResource(AppConfig.PROFILE_PICTURE);
        ((TextView) v.findViewById(R.id.tvName)).setText(AppConfig.NAME);
        ((TextView) v.findViewById(R.id.tvSubtitle)).setText(AppConfig.SUBTITLE);
        ((TextView) v.findViewById(R.id.tvIntro)).setText(AppConfig.HOME_INTRO);

        v.findViewById(R.id.btnProjects).setOnClickListener(b -> ((MainActivity) requireActivity()).navigate(R.id.nav_projects));
        v.findViewById(R.id.btnContact).setOnClickListener(b ->
                IntentUtil.openUrl(requireContext(), "https://wa.me/" + AppConfig.WHATSAPP_NUMBER));
        AnimUtil.pressEffect(v.findViewById(R.id.btnProjects));
        AnimUtil.pressEffect(v.findViewById(R.id.btnContact));

        // Entrance animations (staggered)
        AnimUtil.fadeSlideUp(v.findViewById(R.id.photoFrame), 100);
        AnimUtil.fadeSlideUp(v.findViewById(R.id.tvName), 300);
        AnimUtil.fadeSlideUp(v.findViewById(R.id.tvSubtitle), 450);
        AnimUtil.fadeSlideUp(v.findViewById(R.id.tvIntro), 600);
        AnimUtil.fadeSlideUp(v.findViewById(R.id.buttonRow), 750);

        // Soft pulsing glow behind the photo
        glowAnim = ObjectAnimator.ofPropertyValuesHolder(v.findViewById(R.id.glow),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 0.92f, 1.08f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.92f, 1.08f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 0.5f, 1f));
        glowAnim.setDuration(2200);
        glowAnim.setRepeatCount(ObjectAnimator.INFINITE);
        glowAnim.setRepeatMode(ObjectAnimator.REVERSE);
        glowAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        glowAnim.start();
    }

    @Override
    public void onResume() {
        super.onResume();
        Drawable bg = root == null ? null : root.getBackground();
        if (bg instanceof AnimationDrawable) {           // animated gradient background
            AnimationDrawable ad = (AnimationDrawable) bg;
            ad.setEnterFadeDuration(2500);
            ad.setExitFadeDuration(2500);
            ad.start();
        }
    }

    @Override
    public void onPause() {
        Drawable bg = root == null ? null : root.getBackground();
        if (bg instanceof AnimationDrawable) ((AnimationDrawable) bg).stop();
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        if (glowAnim != null) glowAnim.cancel();   // stop infinite animation
        super.onDestroyView();
    }
}
