package com.sabit.portfolio.adapters;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sabit.portfolio.R;
import com.sabit.portfolio.models.SocialItem;
import com.sabit.portfolio.utils.AnimUtil;
import com.sabit.portfolio.utils.IntentUtil;

import java.util.List;

public class SocialAdapter extends RecyclerView.Adapter<SocialAdapter.VH> {
    private final List<SocialItem> items;
    private int lastAnimated = -1;

    public SocialAdapter(List<SocialItem> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_social, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        SocialItem s = items.get(position);
        h.badge.setText(s.badge);
        h.badge.setBackgroundTintList(ColorStateList.valueOf(s.color));
        h.name.setText(s.name);
        h.desc.setText(s.description);
        AnimUtil.pressEffect(h.itemView);
        h.itemView.setOnClickListener(v -> IntentUtil.openUrl(v.getContext(), s.url));
        if (position > lastAnimated) {
            AnimUtil.fadeSlideUp(h.itemView, position * 80L);
            lastAnimated = position;
        } else {
            h.itemView.setAlpha(1f);
            h.itemView.setTranslationY(0f);
        }
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView badge, name, desc;
        VH(@NonNull View v) {
            super(v);
            badge = v.findViewById(R.id.badge);
            name = v.findViewById(R.id.socialName);
            desc = v.findViewById(R.id.socialDesc);
        }
    }
}
