package com.sabit.portfolio.utils;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

/** Safely opens links (browser, WhatsApp, Telegram, ...) with error handling. */
public final class IntentUtil {
    private IntentUtil() {}

    public static void openUrl(Context context, String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(context, "Link not set yet", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.trim())));
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(context, "No app found to open this link", Toast.LENGTH_SHORT).show();
        }
    }
}
