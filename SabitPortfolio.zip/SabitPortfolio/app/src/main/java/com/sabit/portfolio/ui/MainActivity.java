package com.sabit.portfolio.ui;

import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.sabit.portfolio.R;

/** Hosts the 4 pages and the bottom navigation bar. */
public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bottomNav = findViewById(R.id.bottomNav);

        bottomNav.setOnItemSelectedListener(item -> {
            Fragment f = createFragment(item.getItemId());
            if (f == null) return false;
            show(f);
            return true;
        });
        if (savedInstanceState == null) bottomNav.setSelectedItemId(R.id.nav_home);

        // Back: go to Home first, exit the app only from Home.
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (bottomNav.getSelectedItemId() != R.id.nav_home) {
                    bottomNav.setSelectedItemId(R.id.nav_home);
                } else {
                    finish();
                }
            }
        });
    }

    /** Called by fragments to jump to another tab. */
    public void navigate(int menuId) { bottomNav.setSelectedItemId(menuId); }

    private Fragment createFragment(int id) {
        if (id == R.id.nav_home) return new HomeFragment();
        if (id == R.id.nav_about) return new AboutFragment();
        if (id == R.id.nav_socials) return new SocialsFragment();
        if (id == R.id.nav_projects) return new ProjectsFragment();
        return null;
    }

    private void show(@NonNull Fragment f) {
        getSupportFragmentManager().beginTransaction()
                .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
                .replace(R.id.fragmentContainer, f)
                .commit();
    }
}
