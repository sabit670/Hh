package com.sabit.portfolio.models;

/** One social media card. */
public class SocialItem {
    public final String name, description, url, badge;
    public final int color; // badge background color

    public SocialItem(String name, String description, String url, String badge, int color) {
        this.name = name; this.description = description; this.url = url; this.badge = badge; this.color = color;
    }
}
