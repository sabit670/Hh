package com.sabit.portfolio.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.sabit.portfolio.R;
import com.sabit.portfolio.models.Skill;
import com.sabit.portfolio.utils.AnimUtil;
import com.sabit.portfolio.utils.AppConfig;

public class AboutFragment extends Fragment {

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle s) {
        return inflater.inflate(R.layout.fragment_about, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        ((ImageView) v.findViewById(R.id.ivAbout)).setImageResource(AppConfig.PROFILE_PICTURE);
        ((TextView) v.findViewById(R.id.tvAboutName)).setText(AppConfig.NAME);
        ((TextView) v.findViewById(R.id.tvAboutIntro)).setText(AppConfig.ABOUT_INTRO);
        ((TextView) v.findViewById(R.id.tvJourney)).setText(AppConfig.JOURNEY);
        ((TextView) v.findViewById(R.id.tvInterests)).setText(AppConfig.INTERESTS);
        ((TextView) v.findViewById(R.id.tvGoals)).setText(AppConfig.GOALS);

        // Build one animated card per skill
        LinearLayout box = v.findViewById(R.id.skillsContainer);
        int i = 0;
        for (Skill sk : AppConfig.getSkills()) {
            View card = LayoutInflater.from(requireContext()).inflate(R.layout.item_skill, box, false);
            ((TextView) card.findViewById(R.id.skillName)).setText(sk.name);
            ((TextView) card.findViewById(R.id.skillDesc)).setText(sk.description);
            ((TextView) card.findViewById(R.id.skillPercent)).setText(sk.level + "%");
            ProgressBar bar = card.findViewById(R.id.skillBar);
            bar.setProgress(0);
            box.addView(card);
            long delay = 300 + i * 120L;
            AnimUtil.fadeSlideUp(card, delay);
            bar.postDelayed(() -> {                       // progress bar fills smoothly
                if (isAdded()) {
                    android.animation.ObjectAnimator.ofInt(bar, "progress", 0, sk.level).setDuration(900).start();
                }
            }, delay + 200);
            i++;
        }
        AnimUtil.fadeSlideUp(v.findViewById(R.id.ivAbout), 0);
        AnimUtil.fadeSlideUp(v.findViewById(R.id.tvAboutName), 100);
    }
}
