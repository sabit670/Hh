package com.sabit.portfolio.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.sabit.portfolio.R;
import com.sabit.portfolio.utils.AnimUtil;

/** Splash screen: shows logo + name, then opens MainActivity. */
public class SplashActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable goNext = () -> {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        AnimUtil.fadeSlideUp(findViewById(R.id.splashLogo), 100);
        AnimUtil.fadeSlideUp(findViewById(R.id.splashName), 350);
        AnimUtil.fadeSlideUp(findViewById(R.id.splashTag), 600);
        handler.postDelayed(goNext, 2200);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(goNext);   // avoid leaks / double start
        super.onDestroy();
    }
}
