package com.sabit.portfolio.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sabit.portfolio.R;
import com.sabit.portfolio.models.Project;
import com.sabit.portfolio.utils.AnimUtil;
import com.sabit.portfolio.utils.IntentUtil;

import java.util.List;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.VH> {
    private final List<Project> items;
    private int lastAnimated = -1;

    public ProjectAdapter(List<Project> items) { this.items = items; }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new VH(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_project, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Project p = items.get(position);
        h.name.setText(p.name);
        h.desc.setText(p.description);
        h.tech.setText(p.tech);
        if (p.imageRes != 0) {              // custom thumbnail
            h.image.setPadding(0, 0, 0, 0);
            h.image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            h.image.setImageResource(p.imageRes);
        }
        AnimUtil.pressEffect(h.open);
        h.open.setOnClickListener(v -> IntentUtil.openUrl(v.getContext(), p.url));
        if (position > lastAnimated) {
            AnimUtil.fadeSlideUp(h.itemView, position * 100L);
            lastAnimated = position;
        } else {
            h.itemView.setAlpha(1f);
            h.itemView.setTranslationY(0f);
        }
    }

    @Override public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView name, desc, tech;
        final ImageView image;
        final View open;
        VH(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.projectName);
            desc = v.findViewById(R.id.projectDesc);
            tech = v.findViewById(R.id.projectTech);
            image = v.findViewById(R.id.projectImage);
            open = v.findViewById(R.id.btnOpen);
        }
    }
}
