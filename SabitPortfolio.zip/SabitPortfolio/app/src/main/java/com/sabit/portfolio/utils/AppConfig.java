package com.sabit.portfolio.utils;

import android.graphics.Color;

import com.sabit.portfolio.R;
import com.sabit.portfolio.models.Project;
import com.sabit.portfolio.models.SocialItem;
import com.sabit.portfolio.models.Skill;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 *  CENTRAL CONFIGURATION - EDIT EVERYTHING ABOUT YOU HERE
 * ============================================================
 * Profile picture: replace app/src/main/res/drawable-nodpi/profile.jpg
 * (keep the same file name) or change PROFILE_PICTURE below.
 */
public final class AppConfig {
    private AppConfig() {}

    // ---------- Personal info ----------
    public static final String NAME = "SABIT SIDDIQUE";
    public static final String SUBTITLE = "Programmer | Developer | Dreamer";
    public static final int PROFILE_PICTURE = R.drawable.profile;

    public static final String HOME_INTRO =
            "Hi, I'm Sabit! I love turning ideas into real Android apps with Java. "
          + "Welcome to my personal portfolio.";

    public static final String ABOUT_INTRO =
            "I'm Sabit Siddique, a passionate learner and Android developer. "
          + "I enjoy building clean, useful and good-looking apps.";

    public static final String JOURNEY =
            "My programming journey started with curiosity about how apps work. "
          + "I began learning Java, moved on to Android Studio, and now I build my own apps and keep improving every day.";

    public static final String INTERESTS =
            "• Android app development\n• Java programming\n• UI / UX design\n• Learning new technologies";

    public static final String GOALS =
            "• Become a professional Android developer\n• Build apps that help many people\n• Publish apps on the Play Store\n• Keep learning and growing";

    // ---------- Contact ----------
    /** WhatsApp number in international format, digits only (e.g. 8801XXXXXXXXX). */
    public static final String WHATSAPP_NUMBER = "8801XXXXXXXXX";

    // ---------- Social links (replace the placeholders) ----------
    public static List<SocialItem> getSocials() {
        List<SocialItem> l = new ArrayList<>();
        l.add(new SocialItem("Facebook", "Follow my page & updates", "https://facebook.com/YOUR_USERNAME", "f", Color.parseColor("#1877F2")));
        l.add(new SocialItem("Instagram", "Photos and daily life", "https://instagram.com/YOUR_USERNAME", "IG", Color.parseColor("#E1306C")));
        l.add(new SocialItem("WhatsApp", "Chat with me directly", "https://wa.me/" + WHATSAPP_NUMBER, "WA", Color.parseColor("#25D366")));
        l.add(new SocialItem("GitHub", "My code & projects", "https://github.com/YOUR_USERNAME", "GH", Color.parseColor("#6E5494")));
        l.add(new SocialItem("Telegram", "Message me on Telegram", "https://t.me/YOUR_USERNAME", "TG", Color.parseColor("#229ED9")));
        l.add(new SocialItem("YouTube", "Watch my videos", "https://youtube.com/@YOUR_CHANNEL", "YT", Color.parseColor("#FF0000")));
        return l;
    }

    // ---------- Skills ----------
    public static List<Skill> getSkills() {
        List<Skill> l = new ArrayList<>();
        l.add(new Skill("Java Programming", "Core Java, OOP and problem solving", 80));
        l.add(new Skill("Android Development", "Activities, Fragments, XML UI, Intents", 75));
        l.add(new Skill("Basic Computer Skills", "Windows, internet, office tools", 85));
        l.add(new Skill("App Development", "From idea to a working app", 70));
        return l;
    }

    // ---------- Projects (add as many as you like!) ----------
    // Project(name, description, technology, link, imageRes) - use 0 for the default thumbnail.
    public static List<Project> getProjects() {
        List<Project> l = new ArrayList<>();
        l.add(new Project("Personal Portfolio App", "This very app - my personal brand in a native Android app.",
                "Java • XML • Material", "https://github.com/YOUR_USERNAME/portfolio-app", 0));
        l.add(new Project("Project Two", "Short description of your next project goes here.",
                "Java • Android", "https://github.com/YOUR_USERNAME/project-two", 0));
        return l;
    }
}
