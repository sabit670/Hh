package com.sabit.portfolio.models;

/** One portfolio project. imageRes = 0 means "use the default thumbnail". */
public class Project {
    public final String name, description, tech, url;
    public final int imageRes;

    public Project(String name, String description, String tech, String url, int imageRes) {
        this.name = name; this.description = description; this.tech = tech; this.url = url; this.imageRes = imageRes;
    }
}
